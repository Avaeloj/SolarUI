SLASH_SOLARUI1, SLASH_SOLARUI2 = '/SolarUI', "/sui"
function SlashCmdList.SOLARUI(msg, editbox)
  print("Welcome to SolarUI Version [0.8]")
end


-- SLASH_HELLOWORLD1, SLASH_HELLOWORLD2 = '/hiw', '/hellow'; -- 3.
-- function SlashCmdList.HELLOWORLD(msg, editbox) -- 4.
 -- print("Hello, World!");
-- end
--[[SLASH_HELLOWORLD1, SLASH_HELLOWORLD2 = '/hiw', '/hellow';
local function handler(msg, editbox)
 if msg == 'bye' then
  print('Goodbye, World!');
 else
  print("Hello, World!");
 end
end
SlashCmdList["HELLOWORLD"] = handler;]]--