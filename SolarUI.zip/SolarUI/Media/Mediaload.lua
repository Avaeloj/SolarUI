<Ui xmlns="http://www.blizzard.com/wow/ui/">	
	<Script file="sharedmedia.lua"/>
</Ui>